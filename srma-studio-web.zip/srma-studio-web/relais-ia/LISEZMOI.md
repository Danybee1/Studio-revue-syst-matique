# Relais IA — mode d'emploi

L'assistant IA de SR·MA Studio a besoin d'une clé API Anthropic. Une page web
publique ne peut pas détenir cette clé : tout visiteur lirait le code source et
consommerait votre budget. Ce relais résout le problème — la clé vit sur le
serveur, le navigateur ne voit qu'une URL.

Coût : le plan gratuit de Cloudflare Workers couvre 100 000 requêtes par jour,
soit très au-delà des besoins d'une équipe de recherche. Vous ne payez que la
consommation de l'API Anthropic elle-même.

## Déploiement en cinq étapes

1. **Créer une clé API** sur https://console.anthropic.com → *API Keys*.
   Créez-en une dédiée à ce projet : vous pourrez la révoquer seule en cas de
   problème, et suivre sa consommation séparément.

2. **Installer les outils** (Node.js 18 ou plus requis) :
   ```bash
   cd relais-ia
   npm install -g wrangler
   npx wrangler login
   ```

3. **Déclarer l'origine autorisée.** Dans `worker.js`, remplacez la valeur de
   `ORIGINE_AUTORISEE` par l'URL exacte de votre application, sans barre finale :
   ```js
   const ORIGINE_AUTORISEE = "https://abdoulaye.github.io";
   ```
   Cette ligne est votre serrure : sans elle, n'importe quel site pourrait
   appeler votre relais.

4. **Déposer la clé et publier :**
   ```bash
   npx wrangler secret put ANTHROPIC_API_KEY   # collez la clé quand c'est demandé
   npx wrangler deploy
   ```
   Wrangler affiche alors l'URL du relais, du type
   `https://srma-relais.votre-compte.workers.dev`.

5. **Brancher l'application.** Dans `index.html`, en tête du script, collez
   cette URL :
   ```js
   const AI_ENDPOINT = "https://srma-relais.votre-compte.workers.dev";
   ```
   Republiez le fichier. L'onglet Assistant IA passe au vert.

## Vérification

```bash
curl -X POST https://srma-relais.votre-compte.workers.dev \
  -H "Content-Type: application/json" \
  -H "Origin: https://abdoulaye.github.io" \
  -d '{"max_tokens":50,"system":"Réponds en un mot.","messages":[{"role":"user","content":"Test"}]}'
```
Une réponse JSON contenant un bloc `content` confirme que tout fonctionne. Une
erreur 403 signifie que l'en-tête `Origin` ne correspond pas à
`ORIGINE_AUTORISEE`.

## Ce que le relais protège — et ce qu'il ne protège pas

Il **protège la clé** : elle ne quitte jamais Cloudflare. Il **impose le modèle
et les plafonds** de jetons côté serveur, donc un visiteur ne peut pas
détourner le relais pour lui faire écrire un roman.

Il ne **fait pas d'authentification** : toute personne connaissant l'URL de
votre application peut déclencher des appels. Pour un outil interne à l'ARSN ou
au laboratoire, ajoutez une vérification de mot de passe partagé dans
`worker.js`, ou publiez l'application derrière un accès restreint.

Documentation de l'API : https://docs.claude.com/en/api/overview
