/**
 * Relais IA pour SR·MA Studio — Cloudflare Worker
 * ---------------------------------------------------------------------------
 * Rôle : recevoir les requêtes de l'application hébergée et les transmettre à
 * l'API Anthropic en y ajoutant la clé, qui reste stockée côté serveur et
 * n'est jamais exposée au navigateur.
 *
 * Déploiement : voir LISEZMOI.md dans ce dossier.
 * ---------------------------------------------------------------------------
 */

/* ⚠ À MODIFIER : l'URL exacte où vous publiez l'application, sans barre finale.
   Sans cette restriction, n'importe quel site pourrait consommer votre budget. */
const ORIGINE_AUTORISEE = "https://votre-pseudo.github.io";

/* Plafonds de sécurité : bornent le coût d'une requête isolée. */
const MAX_TOKENS = 1500;
const MAX_CARACTERES_SYSTEME = 4000;
const MAX_CARACTERES_MESSAGE = 20000;
const MODELE = "claude-sonnet-4-6";

export default {
  async fetch(request, env) {
    const origine = request.headers.get("Origin");
    const cors = {
      "Access-Control-Allow-Origin": ORIGINE_AUTORISEE,
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Max-Age": "86400",
      "Vary": "Origin"
    };

    // Requête préparatoire du navigateur
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (request.method !== "POST") return erreur("Méthode non autorisée", 405, cors);
    if (origine !== ORIGINE_AUTORISEE) return erreur("Origine non autorisée", 403, cors);
    if (!env.ANTHROPIC_API_KEY) return erreur("Clé API absente du Worker (wrangler secret put ANTHROPIC_API_KEY)", 500, cors);

    let recu;
    try {
      recu = await request.json();
    } catch {
      return erreur("Corps de requête illisible", 400, cors);
    }

    // On ne relaie que ce dont l'application a besoin : le modèle et les
    // plafonds sont imposés ici, pas dictés par le navigateur.
    const messages = (recu.messages || []).slice(0, 2).map((m) => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content ?? "").slice(0, MAX_CARACTERES_MESSAGE)
    }));
    if (!messages.length) return erreur("Aucun message fourni", 400, cors);

    const charge = {
      model: MODELE,
      max_tokens: Math.min(Number(recu.max_tokens) || 1000, MAX_TOKENS),
      system: String(recu.system ?? "").slice(0, MAX_CARACTERES_SYSTEME),
      messages
    };

    let reponse;
    try {
      reponse = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-api-key": env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01"
        },
        body: JSON.stringify(charge)
      });
    } catch (e) {
      return erreur("Appel à l'API impossible : " + e.message, 502, cors);
    }

    const corps = await reponse.text();
    return new Response(corps, {
      status: reponse.status,
      headers: { ...cors, "Content-Type": "application/json" }
    });
  }
};

function erreur(message, code, cors) {
  return new Response(JSON.stringify({ error: { message } }), {
    status: code,
    headers: { ...cors, "Content-Type": "application/json" }
  });
}
